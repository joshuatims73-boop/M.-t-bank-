# UST Credit Union — GitHub APK Project

This project builds an Android APK wrapper for the existing UST Credit Union simulated web application.

## Build on GitHub

1. Create a new GitHub repository.
2. Upload the contents of this project to the repository root.
3. Commit them to `main`.
4. Open **Actions**.
5. Select **Build APK**.
6. Click **Run workflow** if needed.
7. Open the completed run.
8. Download the **UST-Credit-Union-APK** artifact.
9. Extract it and install `app-debug.apk` on your Android phone.

The APK loads the hosted app at:
https://harborbank-personal-bfnrh8.v2.appdeploy.ai/

This is a simulated banking interface. It does not connect to real bank accounts, payment networks, Zelle, Cash App, or other financial systems.
